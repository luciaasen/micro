Instructions to execute all the files properly:

EXERCISE 1 (p4a.com): It follows the requirements of the statement.

EXERCISE 2 (p4b.exe): It is a program based on the exercise C, so it requests a command 
(dec, cod, quit) and then a string to work with it.

EXERCISE 3 (p4c.com):
To install the RTC just execute the program with '/I', also run with '/U' to uninstall.
To run the test program execute it without any parameters, instead of giving the driver
status it starts a similar loop to the exercise 2. As it uses independent interruptions
with ex. 1 it prints twice each string, one with the encode/decode int and another 'step by step'
using the RTC.